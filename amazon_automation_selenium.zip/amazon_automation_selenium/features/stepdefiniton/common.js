const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By, by, Key, Builder, WebElement } = require("selenium-webdriver");
const cred = require("./credendtials");
const { expect } = require("chai");
const { setDefaultTimeout } = require("@cucumber/cucumber");
const { initDriver } = require("../support/driverUtil");
setDefaultTimeout(60 * 1000);

const chrome = require("chromedriver");

let driver;

Before(function () {
  driver = initDriver();
});
After(function () {
  // driver.quit();
});

Given("I am on the home page of Amazon", async function () {
  await driver.get(cred.url);
});
