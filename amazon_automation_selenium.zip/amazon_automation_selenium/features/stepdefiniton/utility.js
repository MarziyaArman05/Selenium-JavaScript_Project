var base64 = require("base-64");
const cred = require("./credendtials");

class Utility {
  static decodedData(string) {
    return base64.decode(cred[string]);
    
  }

}
module.exports = Utility;
