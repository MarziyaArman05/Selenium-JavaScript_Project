const cred = {
  url: "https://www.amazon.in/",
  emailId: "OTQxOTQzOTgxOQ==",
  password: "TWFyeml5YUAxMjMK",
  userName: "RmF0aW1hIEFybWFu",
  userPhoneNumber: "NzA1MTQ5ODE0Ng==",
  userEmailId: "YXJtYW4wNUBnbWFpbC5jb20=",
  userPassword: "QXJtYW5AMTIz",
};
module.exports = cred;
