const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By, Key, Builder, WebElement } = require("selenium-webdriver");
const until = require("selenium-webdriver/lib/until");
const { dict } = require("./locator");
const Utility = require("./utility");

Then("I should see the sign in button on the header", async function () {
  driver.findElement(By.id(dict["signinButton"])).isDisplayed();
});
When("I click on the sign in button on the header", async function () {
  await driver.findElement(By.id(dict["signinButton"])).click();
});
Then("I should see the tab on the page", async function () {
  await driver.findElement(By.css(dict["signinTab"])).isDisplayed();
});

Then(
  "I fill the {string} on the input field and click continue button",
  async function (string) {
    const emailInput = await driver.findElement(By.id(dict["email"]));
    console.log("this", emailInput);
    emailInput.sendKeys(Utility.decodedData(string));
    driver.findElement(By.id("continue")).click();
  }
);
Then("I fill {string} password on the input field", async function (string) {
  await driver.wait(until.elementLocated(By.css(dict["password"])), 10000);
  let element = await driver.findElement(By.css(dict["password"]));
  await element.sendKeys(Utility.decodedData(string) + "\n");
});

Then("I should see the verification tab", function () {
  driver.findElement(By.className(dict["verificationTab"])).isDisplayed();
});
Then("I should see my acccount is visible", function () {
  driver.findElement(By.css(dict["accountName"])).isDisplayed();
});
When("I click on create your amazon account button", async function () {
  await driver.findElement(By.css(dict["createAccountButton"])).click();
});

Then("I fill the {string} on the name input field", async function (string) {
  await driver.wait(until.elementLocated(By.css(dict["customerName"])), 10000);
  await driver
    .findElement(By.css(dict["customerName"]))
    .sendKeys(Utility.decodedData(string));
});
Then("I fill the {string} on the phone input field", async function (string) {
  await driver
    .findElement(By.css(dict["customerPhoneNumber"]))
    .sendKeys(Utility.decodedData(string) + "\n");
});
Then("I fill the {string} on the email input field", async function (string) {
  await driver
    .findElement(By.id(dict["email"]))
    .sendKeys(Utility.decodedData(string) + "\n");
});
Then(
  "I fill the {string} on the password input field",
  async function (string) {
    await driver
      .findElement(By.css(dict["password"]))
      .sendKeys(Utility.decodedData(string) + "\n");
  }
);
Then(
  "I should see the puzzle verification tab",
  { timeout: 60 * 1000 },
  async function () {
    await driver
      .findElement(By.css(dict["puzzleVerificationTab"]))
      .isDisplayed();
  }
);
