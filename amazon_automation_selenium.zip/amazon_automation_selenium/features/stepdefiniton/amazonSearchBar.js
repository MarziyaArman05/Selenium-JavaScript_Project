const { Given, Then, When, Before, After } = require("@cucumber/cucumber");
const { By} = require("selenium-webdriver");
const until = require("selenium-webdriver/lib/until");
const { dict } = require("./locator");

Then("I should see the header of the home page", async function () {
  let text = await driver.findElement(By.id(dict["header"])).getText();
});

When(
  "I should see the Search Bar on the header",
  { timeout: 60 * 1000 },
  async function () {
    let text = await driver.findElement(By.id(dict["searchbar"])).getText();
  }
);

When(
  "I fill product {string} name on the search bar",
  { timeout: 60 * 1000 },
  async function (string) {
    await driver.findElement(By.name(dict["product"])).sendKeys(string + "\n");
  }
);
Then("I click on search button on the page", function () {
  driver.findElement(By.id(dict["searchButton"])).click();
});

When("I should be navigated to search item page", async function () {
  await driver.findElement(By.id(dict["searchItem"]));
});

When("I click the items", async function () {
  let element = await driver.findElement(By.className(dict["item"]));
  await element.click();
  let alltabs = await driver.getAllWindowHandles();
  await driver.switchTo().window(alltabs[1]);
  await driver.wait(
    until.elementLocated(By.id(dict["addToCartButton"])),
    10000
  );
});
Then("I navigate to the items details page", async function () {
  const strUrl = driver
    .getCurrentUrl()
    .then((result) => result.includes("school"));
});

When(
  "I click the Add to Cart button",
  { timeout: 60 * 1000 },
  async function () {
    let item = await driver.findElement(By.id(dict["addToCartButton"]));
    item.click();
  }
);

Then("I check the item available in add to cart page", async function () {
  let text = await driver.findElement(By.className(dict["checkItem"]));
});
